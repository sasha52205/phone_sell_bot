from .admin import dp
from .testing import dp
from .start import dp
from .support import dp
from .help import dp
from .update_db import dp

__all__ = ["dp"]
