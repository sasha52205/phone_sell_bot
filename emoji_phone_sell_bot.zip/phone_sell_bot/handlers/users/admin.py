from asyncio import sleep
from typing import List
import re
from aiogram.utils.exceptions import BotBlocked, TelegramAPIError
from aiogram import types
from aiogram.dispatcher import FSMContext
from aiogram.dispatcher.filters.builtin import CommandStart, Text, Command
from aiogram.types import ReplyKeyboardRemove, ContentType, CallbackQuery, InlineKeyboardButton, InlineKeyboardMarkup

from data.config import admins
from handlers.users.blocklists import banned, shadowbanned
from keyboards.default.menu_kb import choice_items, return_kb, back_kb, admin_kb
from keyboards.inline.support import support_keyboard, get_support_manager
from loader import dp, bot
from states.states import Test
from utils.db_api import quick_commands as commands
from aiogram_media_group import MediaGroupFilter, media_group_handler
from aiogram.dispatcher.filters import IsReplyFilter, IDFilter

from utils.set_bot_commands import set_bot_commands






@dp.message_handler(Text(equals=["Статистика"]),IDFilter(chat_id=admins[0]), state='*')
async def add_mailing(message: types.Message, state: FSMContext):
    supports = await commands.select_all_supports()
    suppotrs_ids = []
    result = str()

    for support in supports:
        suppotrs_ids.append(support.id)
    count = await commands.count_users()
    await message.answer(f'Всего пользователей: {count}\n\n'
                         f'Всего операторов: {len(suppotrs_ids)}', reply_markup=admin_kb)
    await state.reset_state()
    if len(suppotrs_ids) == 0:
        await message.answer('Бот не будет работать, пока вы не добавите хотя бы 1 оператора!')
    await state.finish()
# Фича для рассылки по юзерам (учитывая их язык)
@dp.message_handler(Text(equals=["Рассылка по пользователям"]),IDFilter(chat_id=admins[0]), state='*')
async def add_mailing(message: types.Message, state: FSMContext):
    await message.answer(f'Пришлите текст рассылки')
    await state.set_state('mailing')

@dp.message_handler(Text(equals=["Управление операторами"]),IDFilter(chat_id=admins[0]),state='*')
async def add_sup(message: types.Message, state: FSMContext):
    markup = InlineKeyboardMarkup(
        inline_keyboard=
        [
            [InlineKeyboardButton(text="Отмена", callback_data="otmena")],
        ]
    )
    supports = await commands.select_all_supports()
    sup_list = []
    for support in supports:
        sup_list.append(f'@{support.name}  -- <code>{support.id}</code>\n')

    st = ''.join(sup_list)

    await message.answer(f'Список операторов:\n\n'
                              f'{st}')
    await message.answer(
        'Пришлите мне числовой id пользователя, которого хотите назначить оператором или нажмите отмена\n\n'
        'id пользователя можно узнать через @my_id_bot\n\n'
        'Для удаления оператора, пришлите id оператора из списка', reply_markup=markup)
    await state.set_state('add_support')




@dp.message_handler(state='mailing')
async def mailing(message: types.Message, state: FSMContext):
    text = message.text
    await state.update_data(text=text)
    yes_no_kb = InlineKeyboardMarkup(
        inline_keyboard=
        [
            [InlineKeyboardButton(text="Да, начать", callback_data="yes")],
            [InlineKeyboardButton(text="Нет, отменить", callback_data="no")],
        ]
    )
    await message.answer(f'Начать рассылку всем пользователем с таким текстом ?\n\n'
                         f'<i>{message.text}</i>', reply_markup=yes_no_kb)


@dp.callback_query_handler(text_contains="yes", state='mailing')
async def mailing_start(call: types.CallbackQuery, state: FSMContext):
    data = await state.get_data()
    text = data.get("text")
    await state.reset_state()
    await call.message.edit_reply_markup()

    users = await commands.select_all_users()
    for user in users:
        try:
            await bot.send_message(chat_id=user.id,
                                   text=text)
            await sleep(0.3)
        except Exception:
            pass
    await call.message.answer("Рассылка выполнена.")


@dp.callback_query_handler(text_contains="no", state='mailing')
async def mailing_start(call: types.CallbackQuery, state: FSMContext):
    await state.finish()
    await call.message.edit_reply_markup()
    await call.message.answer('Рассылка отменена!')




@dp.message_handler(state='add_support')
async def mailing(message: types.Message, state: FSMContext):
    text = message.text
    try:
        user = await commands.select_user(id=int(message.text))
        if user.status == 'support':
            await commands.update_user_email(id=int(text), status=None)
            await bot.send_message(chat_id=text, text='Вы больше не являетесь оператором!\n'
                                                      'Нажмите /start для перезапуска бота')
            await message.answer('Теперь этот пользователь не является оператором.')
            await state.finish()
            await set_bot_commands(dp, admins)
        else:
            await commands.update_user_email(id=int(text), status='support')
            await bot.send_message(chat_id=text, text='Администратор назначил вас оператором\n'
                                                      'Нажмите /start для перезапуска бота')
            await message.answer('Назначил пользователя оператором и сообщил ему об этом!')
            await state.finish()
            await set_bot_commands(dp, admins)
    except:
        await message.answer('Ошибка!\n\n'
                             'Проверьте, присутствует ли данный пользователь в боте\n'
                             'И правильность ввода id (только цифры!)')


@dp.callback_query_handler(text_contains="otmena", state='*')
async def mailing_start(call: types.CallbackQuery, state: FSMContext):
    await state.finish()
    await call.message.edit_text('Вы отменили данное дейвствие')
