banned = set()
shadowbanned = set()