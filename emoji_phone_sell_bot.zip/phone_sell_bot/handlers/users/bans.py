from contextlib import suppress

from aiogram import Dispatcher, types
from aiogram.dispatcher.filters import IsReplyFilter, IDFilter, Command

from blocklists import banned, shadowbanned
from data.config import admins

from handlers.users.start import extract_id
from loader import dp


@dp.message_handler(Command("ban"), IsReplyFilter(is_reply=True), IDFilter(chat_id=admins[0]))
async def cmd_ban(message: types.Message):
    try:
        user_id = extract_id(message)
    except ValueError as ex:
        return await message.reply(str(ex))
    banned.add(int(user_id))
    await message.reply(
        f"ID {user_id} добавлен в список заблокированных. "
        f"При попытке отправить сообщение пользователь получит уведомление о том, что заблокирован."
    )

@dp.message_handler(Command("shadowban"), IsReplyFilter(is_reply=True), IDFilter(chat_id=admins[0]))
async def cmd_shadowban(message: types.Message):
    try:
        user_id = extract_id(message)
    except ValueError as ex:
        return await message.reply(str(ex))
    shadowbanned.add(int(user_id))
    await message.reply(
        f"ID {user_id} добавлен в список скрытно заблокированных. "
        f"При попытке отправить сообщение пользователь не узнает, что заблокирован."
    )

@dp.message_handler(Command("unban"), IsReplyFilter(is_reply=True), IDFilter(chat_id=admins[0]))
async def cmd_unban(message: types.Message):
    try:
        user_id = extract_id(message)
    except ValueError as ex:
        return await message.reply(str(ex))
    user_id = int(user_id)
    with suppress(KeyError):
        banned.remove(user_id)
    with suppress(KeyError):
        shadowbanned.remove(user_id)
    await message.reply(f"ID {user_id} разблокирован")

@dp.message_handler(Command("list_banned"), IsReplyFilter(is_reply=True), IDFilter(chat_id=admins[0]))
async def cmd_list_banned(message: types.Message):
    has_bans = len(banned) > 0 or len(shadowbanned) > 0
    if not has_bans:
        await message.answer("Нет заблокированных пользователей")
        return
    result = []
    if len(banned) > 0:
        result.append("Список заблокированных:")
        for item in banned:
            result.append(f"• #id{item}")
    if len(shadowbanned) > 0:
        result.append("\nСписок скрытно заблокированных:")
        for item in shadowbanned:
            result.append(f"• #id{item}")

    await message.answer("\n".join(result))


