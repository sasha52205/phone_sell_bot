from asyncio import sleep
from typing import List
import re
from aiogram.utils.exceptions import BotBlocked, TelegramAPIError
from aiogram import types
from aiogram.dispatcher import FSMContext
from aiogram.dispatcher.filters.builtin import CommandStart, Text, Command
from aiogram.types import ReplyKeyboardRemove, ContentType, CallbackQuery, InlineKeyboardButton, InlineKeyboardMarkup

from data.config import admins, phone, channels
from handlers.users.blocklists import banned, shadowbanned
from keyboards.default.menu_kb import choice_items, return_kb, back_kb, admin_kb
from keyboards.inline.subscription import check_button
from keyboards.inline.support import support_keyboard, get_support_manager
from loader import dp, bot
from states.states import Test
from utils.db_api import quick_commands as commands
from aiogram_media_group import MediaGroupFilter, media_group_handler
from aiogram.dispatcher.filters import IsReplyFilter, IDFilter

from utils.misc import subscription
from utils.set_bot_commands import set_bot_commands


@dp.callback_query_handler(text="check_subs")
async def checker(call: types.CallbackQuery):
    await call.answer()
    result = str()
    for channel in channels:
        status = await subscription.check(user_id=call.from_user.id,
                                          channel=channel)
        channel = await bot.get_chat(channel)
        if status:
            result += f"Спасибо, что подписались\n\n" \
                      f"Нажмите /start чтобы начать предлагать товар"
        else:
            invite_link = await channel.export_invite_link()
            result += (f"Подписка на канал <b>{channel.title}</b> не оформлена! "
                       f"<a href='{invite_link}'>Нужно подписаться.</a>\n\n")

    await call.message.answer(result, disable_web_page_preview=True)


@dp.message_handler(Command("start"), state='*')
async def bot_start(message: types.Message, state: FSMContext):
    name = message.from_user.full_name
    await commands.add_user(id=message.from_user.id,
                            name=message.from_user.username)
    user = await commands.select_user(id=message.from_user.id)
    supports = await commands.select_all_supports()
    suppotrs_ids = []
    result = str()

    for support in supports:
        suppotrs_ids.append(support.id)
    for channel in channels:
        status = await subscription.check(user_id=message.from_user.id,
                                          channel=channel)
        channel = await bot.get_chat(channel)
        if status:
            if user.status == 'support':
                await message.answer('Новых сообщений нет\n'
                                     'Я сообщу, когда они появятся\n')
                await state.reset_state()
            elif user.id == admins[0]:
                count = await commands.count_users()
                await message.answer(f'Всего пользователей: {count}\n\n'
                                     f'Всего операторов: {len(suppotrs_ids)}', reply_markup=admin_kb)
                await state.reset_state()
                if len(suppotrs_ids) == 0:
                    await message.answer('Бот не будет работать, пока вы не добавите хотя бы 1 оператора!')
            else:
                if len(suppotrs_ids) == 0:
                    await message.answer(f'Извините, в данный момент не покупаем товары.\n'
                                         f'Мы сообщим, когда возобновим работу.\n'
                                         f'Если возникли дополнительные вопросы звоните!\n\n'
                                         f'{phone}')
                else:
                    await message.answer(f'Здравствуйте, {message.from_user.full_name}!\n'
                                         f'Что вы хотите продать?', reply_markup=choice_items)
                    await Test.Q0.set()

                    statte = await state.get_state()
        else:
            channels_format = str()
            for channel in channels:
                chat = await bot.get_chat(channel)
                invite_link = await chat.export_invite_link()
                channels_format += f"Канал <a href='{invite_link}'>{chat.title}</a>\n\n"

            await message.answer(f"Вам необходимо подписаться на следующие каналы: \n"
                                 f"{channels_format}",
                                 reply_markup=check_button,
                                 disable_web_page_preview=True)


