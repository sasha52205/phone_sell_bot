from aiogram.types import ReplyKeyboardMarkup, KeyboardButton

choice_items = ReplyKeyboardMarkup(
    keyboard=[
        [
            KeyboardButton(text="Телефон 📱"),

        ],
        [
            KeyboardButton(text="Планшет 💻"),
        ],
        [
            KeyboardButton(text="Ноутбук 🖥"),
        ],
        [
            KeyboardButton(text="Другое 🎮"),
        ],
    ],
    resize_keyboard=True
)

return_kb = ReplyKeyboardMarkup(
    keyboard=[
        [
            KeyboardButton(text="Предложить еще один товар"),

        ],
    ],
    resize_keyboard=True
)


back_kb = ReplyKeyboardMarkup(
    keyboard=[
        [
            KeyboardButton(text="Назад"),

        ],
    ],
    resize_keyboard=True
)

admin_kb = ReplyKeyboardMarkup(
    keyboard=[
        [
            KeyboardButton(text="Статистика"),

        ],
        [
            KeyboardButton(text="Рассылка по пользователям"),

        ],
        [
            KeyboardButton(text="Управление операторами"),

        ],
    ],
    resize_keyboard=True
)
