


from aiogram.types import BotCommand
from aiogram.types.bot_command_scope import BotCommandScopeDefault, BotCommandScopeChat

from data.config import admins
from utils.db_api import quick_commands as commands
from loader import bot


async def set_bot_commands(dp, admins):
    usercommands = [
        BotCommand(command="start", description="Запустить бота"),
    ]
    await dp.bot.set_my_commands(usercommands, scope=BotCommandScopeDefault())

    support_commands = [
        BotCommand(command="start", description="Перезапустить бота"),
        BotCommand(command="ban", description="Заблокировать пользователя"),
        BotCommand(command="shadowban", description="Скрытно заблокировать пользователя"),
        BotCommand(command="unban", description="Разблокировать пользователя"),
        BotCommand(command="list_banned", description="Список заблокированных"),
    ]
    supports = await commands.select_all_supports()
    for support in supports:
        await dp.bot.set_my_commands(support_commands, scope=BotCommandScopeChat(chat_id=support.id))
    admins_commands = [
        BotCommand(command="start", description="Запустить бота"),
    ]
    await dp.bot.set_my_commands(admins_commands, scope=BotCommandScopeChat(chat_id=admins[0]))
